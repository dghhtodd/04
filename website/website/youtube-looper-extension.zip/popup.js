// 保存設置到Chrome存储
function saveSettings() {
  const loopCount = document.getElementById('loopCount').value;
  const seamlessLoop = document.getElementById('seamlessLoop').checked;
  const autoApply = document.getElementById('autoApply').checked;
  const playlistLoop = document.getElementById('playlistLoop').checked;

  const settings = {
    loopCount: parseInt(loopCount),
    seamlessLoop: seamlessLoop,
    autoApply: autoApply,
    playlistLoop: playlistLoop
  };

  chrome.storage.sync.set(settings, () => {
    showStatus('設置已保存', 'success');
    // 通知content script更新設置
    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      if (tabs[0] && tabs[0].url.includes('youtube.com')) {
        chrome.tabs.sendMessage(tabs[0].id, {
          type: 'settingsUpdated',
          settings: settings
        }, (response) => {
          const handleError = (errorMessage) => {
            console.error('設置更新失敗:', errorMessage);
            showStatus('設置更新失敗: ' + errorMessage, 'error');
            // 延遲1秒後重新載入頁面
            setTimeout(() => {
              chrome.tabs.reload(tabs[0].id);
            }, 1000);
          };

          if (chrome.runtime.lastError) {
            handleError(chrome.runtime.lastError.message);
          } else if (response && response.success) {
            showStatus('設置已更新', 'success');
          } else if (response && response.error) {
            const errorMessage = typeof response.error === 'object' ? 
              JSON.stringify(response.error) : response.error.toString();
            handleError(errorMessage);
          } else {
            handleError('無法與頁面建立連接');
          }
        });
      }
    });
  });
}

// 顯示狀態消息
function showStatus(message, type) {
  const status = document.getElementById('status');
  status.textContent = message;
  status.className = 'status ' + type;
  setTimeout(() => {
    status.className = 'status';
  }, 3000);
}

// 加載保存的設置
function loadSettings() {
  chrome.storage.sync.get({
    loopCount: 1,
    seamlessLoop: false,
    autoApply: false,
    playlistLoop: true
  }, (items) => {
    document.getElementById('loopCount').value = items.loopCount.toString();
    document.getElementById('seamlessLoop').checked = items.seamlessLoop;
    document.getElementById('autoApply').checked = items.autoApply;
    document.getElementById('playlistLoop').checked = items.playlistLoop;
  });
}

// 初始化事件監聽
document.addEventListener('DOMContentLoaded', () => {
  loadSettings();
  document.getElementById('saveSettings').addEventListener('click', saveSettings);
});