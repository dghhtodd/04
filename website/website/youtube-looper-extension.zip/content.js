// 當前循環設置
let currentSettings = {
  loopCount: 1,
  seamlessLoop: false,
  autoApply: false,
  playlistLoop: true // 添加播放清單循環設置
};

let loopCounter = 0;
let originalVideo = null;

// 初始化設置
chrome.storage.sync.get({
  loopCount: 1,
  seamlessLoop: false,
  autoApply: false,
  playlistLoop: true // 添加播放清單循環設置
}, (items) => {
  currentSettings = items;
  if (currentSettings.autoApply) {
    initializeLooper();
  }
});

// 監聽來自popup的設置更新
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'settingsUpdated') {
    // 創建一個Promise來處理異步操作
    const updateSettings = async () => {
      try {
        // 驗證接收到的設置數據
        if (!message.settings || typeof message.settings !== 'object') {
          throw new Error('無效的設置數據格式');
        }

        // 使用解構賦值和空值合併運算符來更新設置
        const { loopCount, seamlessLoop, autoApply, playlistLoop } = message.settings;
        currentSettings = {
          loopCount: loopCount ?? currentSettings.loopCount,
          seamlessLoop: seamlessLoop ?? currentSettings.seamlessLoop,
          autoApply: autoApply ?? currentSettings.autoApply,
          playlistLoop: playlistLoop ?? currentSettings.playlistLoop
        };

        // 初始化循環播放功能
        await Promise.resolve(initializeLooper());
        
        // 記錄成功日誌
        console.log('設置更新成功:', currentSettings);
        return { success: true, data: currentSettings };
      } catch (error) {
        // 詳細記錄錯誤信息
        console.error('設置更新失敗:', {
          error: error.message,
          stack: error.stack,
          settings: message.settings
        });
        return { 
          success: false, 
          error: error.message || '設置更新過程中發生錯誤'
        };
      }
    };

    // 執行異步更新操作
    updateSettings().then(response => {
      try {
        sendResponse(response);
      } catch (error) {
        console.error('發送響應失敗:', error);
      }
    });

    return true; // 保持消息通道開啟
  }
});

// 初始化循環播放功能
function initializeLooper() {
  const video = document.querySelector('video');
  if (!video) return;

  // 保存原始視頻引用
  if (!originalVideo) {
    originalVideo = video.cloneNode(true);
  }

  // 移除現有的事件監聽器
  video.removeEventListener('ended', handleVideoEnd);
  
  // 添加新的事件監聽器
  video.addEventListener('ended', handleVideoEnd);

  // 如果啟用無縫循環，預加載下一段視頻
  if (currentSettings.seamlessLoop) {
    video.addEventListener('timeupdate', handleTimeUpdate);
  }
}

// 處理視頻結束事件
function handleVideoEnd() {
  const video = document.querySelector('video');
  if (!video) return;

  // 獲取播放器實例
  const player = document.querySelector('#movie_player');
  if (!player) return;

  // 檢查是否在播放清單中
  const isInPlaylist = window.location.href.includes('/playlist?');
  
  // 如果在播放清單中且啟用了播放清單循環
  if (isInPlaylist && currentSettings.playlistLoop) {
    // 使用播放器API獲取播放列表信息
    const playlist = player.getPlaylist?.();
    const currentIndex = player.getPlaylistIndex?.();
    
    if (playlist && currentIndex !== undefined) {
      if (currentIndex === playlist.length - 1) {
        // 如果是最後一個視頻，返回到第一個視頻
        player.playVideoAt(0);
      } else {
        // 播放下一個視頻
        player.nextVideo();
      }
      return;
    }

    // 如果無法使用API，則使用DOM操作
    const nextButton = document.querySelector('.ytp-next-button');
    if (nextButton) {
      const playlistItems = document.querySelectorAll('ytd-playlist-panel-video-renderer');
      const currentItem = document.querySelector('ytd-playlist-panel-video-renderer[selected]');
      const isLastVideo = currentItem && Array.from(playlistItems).indexOf(currentItem) === playlistItems.length - 1;

      if (isLastVideo) {
        // 如果是最後一個視頻，點擊播放清單的第一個視頻
        const firstVideo = playlistItems[0];
        if (firstVideo) {
          firstVideo.click();
          return;
        }
      } else {
        // 如果不是最後一個視頻，點擊下一個視頻
        nextButton.click();
        return;
      }
    }
  }

  // 如果不在播放清單中或播放清單循環未啟用，執行普通循環邏輯
  if (currentSettings.loopCount === -1 || loopCounter < currentSettings.loopCount) {
    if (currentSettings.seamlessLoop) {
      // 無縫循環：立即重置視頻時間並播放
      video.currentTime = 0;
      video.play().catch(error => {
        console.error('視頻播放失敗:', error);
        // 如果自動播放失敗，使用更健壯的重試機制
        const retryPlay = async (retries = 3) => {
          for (let i = 0; i < retries; i++) {
            try {
              await video.load();
              await video.play();
              console.log('重試播放成功');
              return;
            } catch (retryError) {
              console.error(`重試播放失敗 (${i + 1}/${retries}):`, retryError);
              await new Promise(resolve => setTimeout(resolve, 1000));
            }
          }
          console.error('所有重試嘗試均失敗');
        };
        retryPlay();
      });
    } else {
      // 普通循環：使用原始視頻重新加載
      const currentTime = video.currentTime;
      video.src = originalVideo.src;
      video.load();
      video.play().catch(error => {
        console.error('視頻播放失敗:', error);
      });
    }
    loopCounter++;
  } else if (currentSettings.loopCount !== -1) {
    // 只有在非無限循環模式下才重置計數器
    loopCounter = 0;
  }
}

// 处理视频时间更新事件（用于无缝循环）
function handleTimeUpdate() {
  const video = document.querySelector('video');
  if (!video) return;

  // 在视频接近结束时预加载
  if (video.currentTime >= video.duration - 1.5) {
    // 预加载下一次播放所需的数据
    if (video.readyState < 4) {
      video.load();
    }
    
    // 如果启用了无缝循环，提前缓存视频
    if (currentSettings.seamlessLoop) {
      const bufferEnd = video.buffered.length > 0 ? video.buffered.end(video.buffered.length - 1) : 0;
      if (bufferEnd < video.duration) {
        video.load();
      }
    }
  }
}

// 添加循环状态指示器
function addLoopIndicator() {
  let indicator = document.createElement('div');
  indicator.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: rgba(0, 0, 0, 0.7);
    color: white;
    padding: 5px 10px;
    border-radius: 4px;
    font-size: 12px;
    z-index: 9999;
  `;
  document.body.appendChild(indicator);

  // 更新指示器状态
  function updateIndicator() {
    const loopText = currentSettings.loopCount === -1 ? '无限循环' : `循环${loopCounter + 1}/${currentSettings.loopCount}次`;
    indicator.textContent = `${loopText} ${currentSettings.seamlessLoop ? '(无缝)' : ''}`;
  }

  // 定期更新指示器
  setInterval(updateIndicator, 1000);
}

// 初始化页面
document.addEventListener('DOMContentLoaded', () => {
  if (window.location.hostname.includes('youtube.com')) {
    initializeLooper();
    addLoopIndicator();
  }
});