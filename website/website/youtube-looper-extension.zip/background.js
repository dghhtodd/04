// 監聽擴充功能安裝或更新事件
chrome.runtime.onInstalled.addListener(() => {
  // 初始化默認設置
  chrome.storage.sync.get({
    loopCount: 1,
    seamlessLoop: false,
    autoApply: false
  }, (items) => {
    chrome.storage.sync.set(items);
  });
});

// 監聽來自content script的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'getSettings') {
    // 獲取當前設置
    chrome.storage.sync.get({
      loopCount: 1,
      seamlessLoop: false,
      autoApply: false
    }, (items) => {
      sendResponse(items);
    });
    return true; // 保持消息通道開啟以進行異步響應
  }
});

// 監聽標籤頁更新事件
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('youtube.com')) {
    // 當YouTube頁面加載完成時，檢查是否需要自動應用設置
    chrome.storage.sync.get({
      autoApply: false
    }, (items) => {
      if (items.autoApply) {
        chrome.tabs.sendMessage(tabId, { type: 'initializeLooper' });
      }
    });
  }
});